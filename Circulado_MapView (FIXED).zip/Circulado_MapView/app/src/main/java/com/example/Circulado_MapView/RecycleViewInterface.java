package com.example.Circulado_MapView;

public interface RecycleViewInterface {
    void onItemClick(int position);

    void onZoom(float scaleFactor);
}