package com.example.circulado_menu;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_EXTERNAL_STORAGE = 1;

    ListView lv;
    List<Person> list = new ArrayList<>();
    List<Person> originalList = new ArrayList<>();
    CustomAdapter adapter;
    String name = null;
    EditText txtSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_EXTERNAL_STORAGE);
        }

        lv = findViewById(R.id.listView1);
        adapter = new CustomAdapter(this, R.layout.item_layout, list);
        lv.setAdapter(adapter);

        txtSearch = findViewById(R.id.editTextText);
        txtSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                filterPerson(charSequence.toString());
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        originalList.addAll(list);
    }

    private void filterPerson(String query) {
        if (list == null || originalList == null) {
            return;
        }
        ArrayList<Person> filteredPerson = new ArrayList<>();

        if (TextUtils.isEmpty(query)) {
            filteredPerson.addAll(originalList);
        } else {
            for (Person person : originalList) {
                if (person.getfirstname() != null && person.getfirstname().toLowerCase().contains(query.toLowerCase())) {
                    filteredPerson.add(person);
                }
            }
        }

        adapter.clear();
        adapter.addAll(filteredPerson);
        adapter.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        ActionBar actionBar = getSupportActionBar();

        if (actionBar != null && name != null && !name.isEmpty()) {
            actionBar.setSubtitle("Name: " + name);
        }
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int option = item.getItemId();
        if (option == R.id.additem) {
            Intent intent = new Intent(this, AddItem.class);
            startActivityForResult(intent, 0);
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == 0) {
                String firstname = data.getStringExtra("firstname");
                String lastname = data.getStringExtra("lastname");
                String imageUri = data.getStringExtra("imageUri");

                Person person = new Person(firstname, lastname, imageUri);
                list.add(person);

                originalList.add(person);
                adapter.notifyDataSetChanged();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_EXTERNAL_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission was granted; you can now access external storage
            } else {
                // Permission was denied; handle the situation appropriately
            }
        }
    }
}
