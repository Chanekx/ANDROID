package com.example.circulado_menu;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

public class AddItem extends AppCompatActivity implements View.OnClickListener {

    EditText firstName,lastName;
    Button btnSave,btnCancel;
    ImageView image;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
        //
        firstName = findViewById(R.id.editText1);
        lastName = findViewById(R.id.editText2);
        image = findViewById(R.id.image);
        btnSave = findViewById(R.id.button);
        btnCancel = findViewById(R.id.button2);
        this.btnSave.setOnClickListener(this);
        this.btnCancel.setOnClickListener(this);



    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id){
            case 2131230819:
                String firstName = this.firstName.getText().toString();
                String lastName = this.lastName.getText().toString();
                //blind inten
                String full = firstName+" "+ lastName;
                Intent intent=new Intent();
                intent.putExtra("name",full);
                this.setResult(Activity.RESULT_OK,intent);

            case 2131230820:
                finish();
        }

        System.out.println(id);
    }
}
