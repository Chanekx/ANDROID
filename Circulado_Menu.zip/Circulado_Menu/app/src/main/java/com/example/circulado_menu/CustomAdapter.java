package com.example.circulado_menu;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends ArrayAdapter<Person> {
    private Context context;
    private int resource;
    private List<Person> items;

    public CustomAdapter(Context context, int resource, List<Person> objects) {
        super(context, resource, objects);
        this.context = context;
        this.resource = resource;
        this.items = objects;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (position < getCount()) {
            if (convertView == null) {
                convertView = LayoutInflater.from(context).inflate(resource, parent, false);
            }

            // The rest of your code to populate the view
            ImageView imageView = convertView.findViewById(R.id.image);
            TextView firstname = convertView.findViewById(R.id.editText1);
            TextView lastname = convertView.findViewById(R.id.editText2);
            ImageView userImageView = convertView.findViewById(R.id.userImageView);

            Person person = getItem(position);
            if (person != null) {
                imageView.setImageResource(person.getImage());
                firstname.setText(person.getfirstname());
                lastname.setText(person.getlastname());

                if (person.getUserImageUri() != null) {
                    userImageView.setImageURI(Uri.parse(person.getUserImageUri()));
                }
            }

            return convertView;
        } else {
            return convertView;
        }
    }
}
