package com.example.circulado_menu;

public class Person {
    private int imageResource;
    private String firstname;
    private String lastname;
    private String userImageUri;

    public Person(String firstname, String lastname, String userImageUri) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.userImageUri = userImageUri;
    }

    public int getImage() {
        return imageResource;
    }

    public void setImage(int imageResource) {
        this.imageResource = imageResource;
    }

    public String getfirstname() {
        return firstname;
    }

    public void setfirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getlastname() {
        return lastname;
    }

    public void setlastnamel(String lastname) {
        this.lastname = lastname;
    }

    public String getUserImageUri() {
        return userImageUri;
    }

    public void setUserImageUri(String userImageUri) {
        this.userImageUri = userImageUri;
    }
}