package com.example.myoptionmenu;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddItem extends AppCompatActivity implements View.OnClickListener {

    EditText txtName;
    Button btnSave,btnCancel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
        //
        txtName = findViewById(R.id.editText2);
        btnSave = findViewById(R.id.button);
        btnCancel = findViewById(R.id.button2);
        this.btnSave.setOnClickListener(this);
        this.btnCancel.setOnClickListener(this);



    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch (id){
            case 2131230819:
               String name = this.txtName.getText().toString();
                //blind inten
                Intent intent=new Intent();
                intent.putExtra("name",name);
                this.setResult(Activity.RESULT_OK,intent);

            case 2131230820:
                finish();
        }

        System.out.println(id);
    }
}



