package com.example.circulado_persondatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;



public class AddItem extends AppCompatActivity implements View.OnClickListener {
     EditText txtName, txtEmail;
    Button btnSave, btnCancel;
    String name, email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
        txtName = findViewById(R.id.name);
        txtEmail = findViewById(R.id.email);
        btnSave = findViewById(R.id.save);
        btnCancel = findViewById(R.id.cancel);
        this.btnSave.setOnClickListener(this);
        this.btnCancel.setOnClickListener(this);
       SpannableString title = new SpannableString("Circulado's Person-Database");
        title.setSpan(new ForegroundColorSpan(Color.parseColor("#72757e")),0,title.length(), 0);
        getSupportActionBar().setTitle(title);
    }

    @Override
    public void onClick(View view) {
        int id = view.getId();
        Intent intent = null;
        if (id==R.id.save){
            name = txtName.getText().toString();
            email = txtEmail.getText().toString();
            //blind intent
            intent = new Intent();
            intent.putExtra("name", name);
            intent.putExtra("email", email);
            intent.putExtra("position", getIntent().getIntExtra("position", -1));
            setResult(Activity.RESULT_OK,intent);
            finish();
        }
        else
            finish();
    }
}