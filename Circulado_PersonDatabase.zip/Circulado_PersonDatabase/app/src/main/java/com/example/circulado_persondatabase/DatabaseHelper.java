package com.example.circulado_persondatabase;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import androidx.annotation.Nullable;
import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper{
    static String DB = "person_db";
    static String PERSON = "tbl_person";

    public DatabaseHelper(@Nullable Context context) {
        super(context, DB, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sql) {
        sql.execSQL("CREATE TABLE " + PERSON + "(id INTEGER PRIMARY KEY AUTOINCREMENT,name varchar(50),email varchar(50))");
    }
    public long addPerson(Person p) {
        long result = -1;
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", p.getName());
        cv.put("email", p.getEmail());
        result = db.insert(PERSON, null, cv);
        db.close();
        return result;
    }

    /*public ArrayList<Person> getAll() {
        ArrayList<Person> list = new ArrayList<Person>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.query(PERSON, null, null, null, null, null, "name");
        c.moveToFirst();
        while (!c.isAfterLast()) {
            String name = c.getString(1);
            String email = c.getString(2);
            Person p = new Person(name, email);
            list.add(p);
            c.moveToNext();
        }
        db.close();
        return list;
    }*/

    public ArrayList<Person> getAll() {
        ArrayList<Person> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        try (Cursor c = db.query(PERSON, null, null, null, null, null, "name")) {
            int nameIndex = c.getColumnIndex("name");
            int emailIndex = c.getColumnIndex("email");

            while (c.moveToNext()) {
                String name = c.getString(nameIndex);
                String email = c.getString(emailIndex);
                Person p = new Person(name, email);
                list.add(p);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Handle the exception according to your application's needs
        }

        db.close();
        return list;
    }

    public int deleteItem(Person p) {
        int result = -1;
        SQLiteDatabase db = this.getWritableDatabase();
        result = db.delete(PERSON, "name = ?", new String[]{p.getName()});
        db.close();
        return result;
    }
   /* public long updateItem(Person p) {
        long result = -1;
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", p.getName());
        cv.put("email", p.getEmail());
        result = db.update(PERSON, cv, "name = ?", new String[]{p.getName()});
        db.close();
        return result;
    }*/
   public long updateItem(Person originalPerson, Person updatedPerson) {
       long result = -1;
       SQLiteDatabase db = this.getWritableDatabase();
       ContentValues cv = new ContentValues();
       cv.put("name", updatedPerson.getName());
       cv.put("email", updatedPerson.getEmail());

       try {
           result = db.update(PERSON, cv, "name = ?", new String[]{originalPerson.getName()});
       } catch (Exception e) {
           e.printStackTrace();
       } finally {
           db.close();
       }

       return result;
   }


    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
