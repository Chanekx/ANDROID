package com.example.circulado_persondatabase;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.SpannableString;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView lv;
    ItemAdapter adapter;
    ArrayList<Person> list = new ArrayList<>();
    String name, email;
    DatabaseHelper db;
    AdapterView.AdapterContextMenuInfo info;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new DatabaseHelper(this);
        list = db.getAll();
        lv = findViewById(R.id.listView);
        adapter = new ItemAdapter(this, list);
        lv.setAdapter(adapter);
        SpannableString title = new SpannableString("Circulado's Menu");
        title.setSpan(new ForegroundColorSpan(Color.parseColor("#72757e")), 0, title.length(), 0);
        getSupportActionBar().setTitle(title);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            }
        });
        registerForContextMenu(lv);
        EditText search = findViewById(R.id.search);
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence s, int i, int i1, int i2) {
                String searchText = s.toString().toLowerCase();
                ArrayList<Person> filteredList = new ArrayList<>();

                for (Person person : list) {
                    if (person.getName().toLowerCase().contains(searchText) || person.getEmail().toLowerCase().contains(searchText)) {
                        filteredList.add(person);
                    }
                }
                adapter = new ItemAdapter(MainActivity.this, filteredList);
                lv.setAdapter(adapter);
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.getMenuInflater().inflate(R.menu.mymenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int option = item.getItemId();
        if (option == R.id.additem) {
            Intent intent = new Intent(this, AddItem.class);
            this.startActivityForResult(intent, 0);
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && data != null) {
            // Inside MainActivity
            if (requestCode == 1) {
                int position = data.getIntExtra("position", -1);
                String newName = data.getStringExtra("name");
                String newEmail = data.getStringExtra("email");

                if (position != -1) {
                    Person originalPerson = list.get(position);
                    Person updatedPerson = new Person(newName, newEmail);

                    long result = db.updateItem(originalPerson, updatedPerson);

                    if (result > 0) {
                        Toast.makeText(this, "Item Edited", Toast.LENGTH_SHORT).show();
                        // Update the list with the edited data
                        list.set(position, updatedPerson);
                        // Notify the adapter of the data change
                        adapter.notifyDataSetChanged();
                    } else {
                        Toast.makeText(this, "Failed to edit", Toast.LENGTH_SHORT).show();
                    }
                }


            } else if (requestCode == 0) {
                Bundle b = data.getExtras();
                name = b.getString("name");
                Person p;
                email = b.getString("email");
                p = new Person(name, email);
                list.add(p);
                long result = db.addPerson(p);
                if (result > 0) {
                    Toast.makeText(this, "New Person Added", Toast.LENGTH_SHORT).show();
                }
                adapter.notifyDataSetChanged();
            }
        }
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.contextmenu, menu);
        info = (AdapterView.AdapterContextMenuInfo) menuInfo;
        menu.setHeaderTitle(list.get(info.position).getName());
    }
    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int position = info.position;
        Person selectedPerson;
        if (position >= 0 && position < list.size()) {
            selectedPerson = list.get(position);
            if (item.getTitle().toString().equals("Edit")) {
                Intent editIntent = new Intent(MainActivity.this, AddItem.class);
                editIntent.putExtra("name", selectedPerson.getName());
                editIntent.putExtra("email", selectedPerson.getEmail());
                editIntent.putExtra("position", position);
                startActivityForResult(editIntent, 1);
                Toast.makeText(this, "Edit Selected", Toast.LENGTH_SHORT).show();
                return true;
            } else if (item.getTitle().equals("Delete")) {
                db.deleteItem(selectedPerson);
                list.remove(position);
                adapter.notifyDataSetChanged();
                Toast.makeText(this, "Delete Selected", Toast.LENGTH_SHORT).show();
                return true;
            }
        }
        return super.onContextItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        db.close(); // Close the database when the activity is destroyed
        super.onDestroy();
    }
}