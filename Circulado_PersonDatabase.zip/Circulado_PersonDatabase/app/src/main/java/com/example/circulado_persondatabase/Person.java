package com.example.circulado_persondatabase;

public class Person {
    private String name, email;

    public Person(String name, String lastname) {
        this.name = name;
        this.email = lastname;
    }
    public String getEmail() {

        return email;
    }
    public void setEmail    (String lastname) {

        this.email = lastname;
    }
    public String getName()
    {
        return name;
    }
    public void setName(String name) {

        this.name = name;
    }
}
