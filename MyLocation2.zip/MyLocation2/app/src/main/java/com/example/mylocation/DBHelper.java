package com.example.mylocation;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    private static String DB = "coordinates_db";
    private static String COORDINATES = "table_coordinates";
    public DBHelper(@Nullable Context context) {
        super(context, DB, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("Create table " + COORDINATES + "(id INTEGER PRIMARY KEY AUTOINCREMENT, latitude nvarchar(50), longitude nvarchar(50))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    public long addCoordinates(Coordinates coordinates){
        long result = 1;
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
            contentValues.put("latitude",coordinates.getLatitude());
            contentValues.put("longitude",coordinates.getLongitude());
            result = database.insert(COORDINATES,null,contentValues);
            database.close();
        return result;
    }
    public ArrayList<Coordinates> getAll(){
        ArrayList<Coordinates> list = new ArrayList<>();
        SQLiteDatabase database = getReadableDatabase();
        Cursor cursor = database.query(COORDINATES,null,null,null,null,null,null,null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            String latitude = cursor.getString(1);
            String longitude = cursor.getString(2);
            Coordinates coordinates = new Coordinates(latitude,longitude);
            list.add(coordinates);
            cursor.moveToNext();
        }
        database.close();

        return list;
    }

    public int deleteAllCoordinates() {
        SQLiteDatabase database = getWritableDatabase();
        int result = database.delete(COORDINATES, null, null);
        database.close();
        return result;
    }

}
