package com.example.mylocation;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import android.view.ScaleGestureDetector;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, LocationListener,RecycleViewInterface,ScaleGestureDetector.OnScaleGestureListener {

    RecyclerView recyclerView;
    MyAdapter adapter;
    ArrayList<Coordinates> list = new ArrayList<>();
    LocationManager locationManager;
    Location location;
    String provider;
    Button btnOkay, btnClear;
    TextView latitude, longitude;
    DBHelper dbHelper;
    ScaleGestureDetector scaleGestureDetector;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.rv);
        adapter = new MyAdapter(this, list,this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new DBHelper(this);
        list.clear();
        list.addAll(dbHelper.getAll());

        latitude = findViewById(R.id.textLatitude);
        longitude = findViewById(R.id.textLongitude);

        btnOkay = findViewById(R.id.btnOkay);
        btnClear = findViewById(R.id.btnClear);

        btnOkay.setOnClickListener(this);
        btnClear.setOnClickListener(this);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            provider = LocationManager.GPS_PROVIDER;
        } else {
            if (locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                provider = LocationManager.NETWORK_PROVIDER;
            }
        }
        scaleGestureDetector = new ScaleGestureDetector(this, this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnOkay) {
            if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            locationManager.requestLocationUpdates(provider, 0, 0, this);
            location = locationManager.getLastKnownLocation(provider);
            if(location != null){
                latitude.setText(String.format("%.6f",location.getLatitude()));
                longitude.setText(String.format("%.6f",location.getLongitude()));

                Coordinates coordinates = new Coordinates(latitude.getText().toString(),longitude.getText().toString());
                list.add(coordinates);

                long ok = dbHelper.addCoordinates(coordinates);
                if(ok < 0){
                    Toast.makeText(this, "Error Adding Coordinates", Toast.LENGTH_SHORT).show();
                }
                adapter.notifyDataSetChanged();
            }
            else {
                Toast.makeText(this,"Error Location",Toast.LENGTH_SHORT).show();
                latitude.setText("Error");
                longitude.setText("Error");
            }
        }
        else {
            latitude.setText("0.00");
            longitude.setText("0.00");

            list.clear();
            adapter.notifyDataSetChanged();
            dbHelper.deleteAllCoordinates();
        }
    }

    @Override
    public boolean onScale(ScaleGestureDetector detector) {
        float scaleFactor = detector.getScaleFactor();
        // Handle zoom with the given scale factor
        // You can add your zooming logic here based on scaleFactor
        // For example, you might want to change the size of your RecyclerView items
        return true;
    }

    @Override
    public boolean onScaleBegin(ScaleGestureDetector detector) {
        // Return true to enter the scaling mode
        return true;
    }

    @Override
    public void onScaleEnd(ScaleGestureDetector detector) {
        // Scaling gesture ended, if needed
    }

    // Override onTouchEvent to pass touch events to ScaleGestureDetector

    @Override
    public void onLocationChanged(@NonNull Location location) {

    }

    @Override
    public void onLocationChanged(@NonNull List<Location> locations) {
        LocationListener.super.onLocationChanged(locations);
    }

    @Override
    public void onFlushComplete(int requestCode) {
        LocationListener.super.onFlushComplete(requestCode);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        LocationListener.super.onStatusChanged(provider, status, extras);
    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {
        LocationListener.super.onProviderEnabled(provider);
    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {
        LocationListener.super.onProviderDisabled(provider);
    }

    @Override
    public void onItemClick(int position) {

        Coordinates clickedCoordinates = list.get(position);
        Toast.makeText(this, "Selected Coordinates: " + clickedCoordinates.getLatitude() + ", " + clickedCoordinates.getLongitude(), Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(this, MapsActivity.class);
        intent.putExtra("latitude", Double.parseDouble(clickedCoordinates.getLatitude()));
        intent.putExtra("longitude", Double.parseDouble(clickedCoordinates.getLongitude()));
        startActivity(intent);

        latitude.setText(clickedCoordinates.getLatitude());
        longitude.setText(clickedCoordinates.getLongitude());
    }
    @Override
    public void onZoom(float scaleFactor) {
        // Handle zoom with the given scale factor
        // You can add your zooming logic here based on scaleFactor
        // For example, you might want to change the size of your RecyclerView items
    }

    // ... (other overridden methods from ScaleGestureDetector.OnScaleGestureListener)

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        scaleGestureDetector.onTouchEvent(event);
        // Handle other touch events if needed
        return true;
    }
}