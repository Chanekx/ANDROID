package com.example.mylocation;

public interface RecycleViewInterface {
    void onItemClick(int position);

    void onZoom(float scaleFactor);
}