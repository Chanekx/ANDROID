const express = require("express");
require("dotenv").config();
const port = process.env.PORT || 4321;
const students = require("./api/students");
const path = require("path");

//create an instance of the express framework
const app = express();

//middlewares
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

app.use("/api/students", students);

//default route
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname,"public","login.html"));
});

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, "public")));

app.listen(port, () => {
  console.log(`listening at port ${port}`);
});
