const express = require("express");
require("dotenv").config();
const mysql = require("mysql");
const router = express.Router()

const db = mysql.createPool({
	host:process.env.DB_HOST,
	user:process.env.DB_USER,
	password:process.env.DB_PASSWORD,
	database:process.env.DB_NAME,
});


//create a route to retrieve data from database
router.get("/",(req,res)=>{
	let sql = "SELECT * FROM `student`"
	db.query(sql,(err,results,fields)=>{
		if(err){
			console.log({error:err});
			res.status(500).json(err);
		}
		res.status(200).json(results);
	});
});

router.post("/login", (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required." });
    }

    const sql = "SELECT * FROM student WHERE username = ? AND password = ?";
    db.query(sql, [username, password], (err, results) => {
        if (err) {
            console.log({ error: err });
            return res.status(500).json({ error: "Internal server error." });
        }

        if (results.length === 0) {
            return res.status(401).json({ message: "Invalid username or password." });
        }

        // If credentials are valid, you can return additional user data if needed
        const user = results[0];
        res.status(200).json({ message: "Login successful.", user });
    });
});


router.post("/signup", (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required." });
    }

    // Check if username already exists
    const checkUsernameQuery = "SELECT * FROM student WHERE username = ?";
    db.query(checkUsernameQuery, [username], (err, results) => {
        if (err) {
            console.log({ error: err });
            return res.status(500).json({ error: "Internal server error." });
        }

        if (results.length > 0) {
            return res.status(409).json({ message: "Username already exists." });
        }

        // Insert new user into the database
        const insertUserQuery = "INSERT INTO student (username, password) VALUES (?, ?)";
        db.query(insertUserQuery, [username, password], (err, result) => {
            if (err) {
                console.log({ error: err });
                return res.status(500).json({ error: "Internal server error." });
            }
            res.status(201).json({ message: "Signup successful." });
        });
    });
});
module.exports = router
