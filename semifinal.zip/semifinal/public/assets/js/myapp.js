var app = angular.module("app",[]);
			app.controller("ctrl",function($scope,$http){
				$http({
					url:'http://172.19.130.115:4321/api/students',
					method:'GET'
				}).then(function(response){
					$scope.students = response.data;
				});
});